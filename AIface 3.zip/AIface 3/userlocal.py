import urllib.request, json
import base64

def f(image_name):
    url = 'https://face-ai.userlocal.jp/api/detect'
    image = open(image_name, 'rb').read()
    b64 = base64.b64encode(image).decode('utf-8')
    params = {
    'api_key': '827BFC458708F0B442009C9C9836F7E4B65557FB',
    'image_base64': b64
    }
    genders = {"male":"男性", "female":"女性"}
    req = urllib.request.Request(url, data=json.dumps(params).encode('utf-8'),
    method='POST', headers={'Content-Type': 'application/json'})
    result = []
    with urllib.request.urlopen(req) as res:
        data = json.loads(res.read().decode('utf-8'))
        result = data['result']
        return result
